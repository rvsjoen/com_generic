<?php
/**
 * @version		1.0.0 2011.06.05
 * @copyright	Copyright (C) 2010-2011 FakeAuthor. All rights reserved.
 * @license		GNU General Public License version 2 or later
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die;
jimport('joomla.application.component.model');

/**
 * This models supports retrieving lists of contact categories.
 *
 * @package		Joomla.Site
 * @subpackage	com_phoneboo
 */
class GenericModelitemlist extends JModel{
	/**
	 * ....
	 */
	public function xxxx(){
	}

}
