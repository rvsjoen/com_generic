<?php
/**
 * @version		1.0.0 2011.06.05
 * @package		Joomla.Site
 * @subpackage	com_generic
 * @copyright	Copyright (C) 2010-2011 FakeAuthor. All rights reserved.
 * @license		GNU General Public License version 2 or later
 */

// no direct access
defined('_JEXEC') or die;
?>
<fieldset class="filter-bar">
	<label>Filter:</label>
	<input type="text" name="task" value="">
	<input type="button" name="task" value="Search">
	<input type="button" name="task" value="Clear">
</fieldset>